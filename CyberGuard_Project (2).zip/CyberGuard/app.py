"""
app.py
-------
CyberGuard // URL Threat Detector — Flask application server.

Serves the single-page front end and exposes /scan, which runs an
incoming URL through the whitelist filter and, if not whitelisted, the
feature-extraction + Random Forest classification pipeline described in
the project report.
"""
import re
import time

import joblib
from flask import Flask, jsonify, render_template, request

from feature_extraction import extract_features, feature_row, get_domain

app = Flask(__name__)

# A domain must contain at least one dot and be made up of sane hostname
# characters; this catches empty/garbled input before it ever reaches the
# feature extractor (see report §6.11, "Forms" — basic URL-format validation).
VALID_DOMAIN = re.compile(r"^[a-zA-Z0-9]([a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?)+$")

# ----------------------------------------------------------------------
# Load the trained model once at start-up (not per-request)
# ----------------------------------------------------------------------
model = joblib.load("url_classifier.pkl")

# A small set of well-known, high-traffic trusted domains.
TRUSTED_DOMAINS = {
    "google.com", "www.google.com", "github.com", "www.github.com",
    "wikipedia.org", "www.wikipedia.org", "microsoft.com", "www.microsoft.com",
    "apple.com", "www.apple.com", "amazon.com", "www.amazon.com",
    "stackoverflow.com", "www.stackoverflow.com", "python.org", "www.python.org",
    "mozilla.org", "www.mozilla.org", "wikipedia.org", "linkedin.com",
    "www.linkedin.com", "reddit.com", "www.reddit.com", "cloudflare.com",
    "www.cloudflare.com",
}

HAZARD_THRESHOLD = 0.5


def build_reasons(features: dict, domain: str) -> list:
    """Human-readable explanations for a flagged URL, mirroring the
    'Flagged features' list shown on the result card."""
    reasons = []
    if features["has_ip_address"]:
        reasons.append("Raw IP address used as host")
    if features["url_length"] > 54:
        reasons.append(f"Unusually long URL ({features['url_length']} characters)")
    if features["special_chars"] >= 5:
        reasons.append(f"{features['special_chars']} special characters ( . - @ )")
    if not features["is_https"]:
        reasons.append("Insecure protocol (HTTP, no TLS)")
    if not reasons:
        reasons.append("Structural pattern statistically similar to known phishing URLs")
    return reasons


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/scan", methods=["POST"])
def scan():
    t0 = time.perf_counter()
    payload = request.get_json(silent=True) or request.form
    raw_url = (payload.get("url") or "").strip()

    if not raw_url:
        return jsonify(error="Please enter a URL to scan."), 400
    if len(raw_url) > 2048:
        return jsonify(error="URL is too long to process."), 400

    domain = get_domain(raw_url)
    if not VALID_DOMAIN.match(domain):
        return jsonify(error="That doesn't look like a valid URL. Check the format and try again."), 400

    if domain in TRUSTED_DOMAINS:
        elapsed = round((time.perf_counter() - t0) * 1000, 1)
        return jsonify(
            verdict="Safe",
            confidence=99.9,
            url=raw_url,
            domain=domain,
            reason="Domain matched trusted whitelist entry",
            protocol="HTTPS (secure)" if raw_url.lower().startswith("https://") else "HTTP",
            flagged=[],
            response_ms=elapsed,
            whitelisted=True,
        )

    features = extract_features(raw_url)
    proba = model.predict_proba(feature_row(raw_url))[0]
    hazard_score = float(proba[1])
    is_threat = hazard_score >= HAZARD_THRESHOLD

    elapsed = round((time.perf_counter() - t0) * 1000, 1)

    return jsonify(
        verdict="Threat Detected" if is_threat else "Safe",
        confidence=round((hazard_score if is_threat else 1 - hazard_score) * 100, 1),
        url=raw_url,
        domain=domain,
        reason=None,
        protocol="HTTPS (secure)" if features["is_https"] else "HTTP (insecure)",
        flagged=build_reasons(features, domain) if is_threat else [],
        features=features,
        response_ms=elapsed,
        whitelisted=False,
    )


if __name__ == "__main__":
    app.run(debug=False, host="127.0.0.1", port=5050)
