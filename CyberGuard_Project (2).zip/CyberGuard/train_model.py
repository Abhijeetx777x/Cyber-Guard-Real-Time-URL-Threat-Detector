"""
train_model.py
---------------
Loads data/url_dataset.csv, extracts structural features from every URL
using feature_extraction.py, trains a Random Forest Classifier, evaluates
it on a held-out test split, and persists the trained model to
url_classifier.pkl for app.py to load at request time.
"""
import json
import time

import joblib
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix
from sklearn.model_selection import train_test_split

from feature_extraction import feature_vector, feature_row, FEATURE_NAMES

DATA_PATH = "data/url_dataset.csv"
MODEL_PATH = "url_classifier.pkl"
METRICS_PATH = "data/metrics.json"


def main():
    df = pd.read_csv(DATA_PATH)
    print(f"Loaded {len(df)} rows from {DATA_PATH}")

    X = pd.DataFrame([feature_vector(u) for u in df["url"]], columns=FEATURE_NAMES)
    y = df["label"]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )

    clf = RandomForestClassifier(n_estimators=200, max_depth=12, random_state=42, n_jobs=-1)
    clf.fit(X_train, y_train)

    # ---- Evaluation ----
    y_pred = clf.predict(X_test)
    acc = accuracy_score(y_test, y_pred)
    prec = precision_score(y_test, y_pred)
    rec = recall_score(y_test, y_pred)
    f1 = f1_score(y_test, y_pred)
    cm = confusion_matrix(y_test, y_pred).tolist()

    # Average per-URL inference time (feature extraction + predict), in ms
    sample_urls = df["url"].sample(200, random_state=1).tolist()
    t0 = time.perf_counter()
    for u in sample_urls:
        clf.predict_proba(feature_row(u))
    avg_ms = (time.perf_counter() - t0) / len(sample_urls) * 1000

    importances = dict(zip(FEATURE_NAMES, clf.feature_importances_.round(4).tolist()))

    metrics = {
        "n_samples": len(df),
        "n_train": len(X_train),
        "n_test": len(X_test),
        "accuracy": round(acc, 4),
        "precision": round(prec, 4),
        "recall": round(rec, 4),
        "f1_score": round(f1, 4),
        "confusion_matrix": cm,  # [[TN, FP], [FN, TP]]
        "avg_inference_ms": round(avg_ms, 3),
        "feature_importances": importances,
    }

    print(json.dumps(metrics, indent=2))

    joblib.dump(clf, MODEL_PATH)
    with open(METRICS_PATH, "w") as f:
        json.dump(metrics, f, indent=2)

    print(f"\nSaved trained model -> {MODEL_PATH}")
    print(f"Saved metrics        -> {METRICS_PATH}")


if __name__ == "__main__":
    main()
