// CyberGuard front-end controller
// Talks to the Flask /scan endpoint and swaps the panel between the
// input state and the result state.

const form = document.getElementById("scan-form");
const input = document.getElementById("url-input");
const scanBtn = document.getElementById("scan-btn");
const fieldError = document.getElementById("field-error");

const stateInput = document.getElementById("state-input");
const stateResult = document.getElementById("state-result");
const resultIcon = document.getElementById("result-icon");
const verdictText = document.getElementById("verdict-text");
const confidenceText = document.getElementById("confidence-text");
const detailUrl = document.getElementById("detail-url");
const reasonRow = document.getElementById("reason-row");
const reasonLabel = document.getElementById("reason-label");
const detailReason = document.getElementById("detail-reason");
const flaggedRow = document.getElementById("flagged-row");
const detailFlagged = document.getElementById("detail-flagged");
const detailProtocol = document.getElementById("detail-protocol");
const detailTime = document.getElementById("detail-time");
const btnReset = document.getElementById("btn-reset");

const ICON_CHECK = `<svg viewBox="0 0 24 24" fill="none"><path d="M5 13l4 4L19 7" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
const ICON_WARN = `<svg viewBox="0 0 24 24" fill="none"><path d="M12 3 L22 20 H2 Z" stroke="currentColor" stroke-width="2.2" stroke-linejoin="round"/><line x1="12" y1="9" x2="12" y2="14" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/><circle cx="12" cy="17" r="1.1" fill="currentColor"/></svg>`;

form.addEventListener("submit", async (e) => {
  e.preventDefault();
  const url = input.value.trim();
  fieldError.textContent = "";

  if (!url) {
    fieldError.textContent = "Please enter a URL to scan.";
    return;
  }
  if (url.length > 2048) {
    fieldError.textContent = "That URL is too long.";
    return;
  }

  await runScan(url);
});

document.querySelectorAll(".chip[data-example]").forEach((chip) => {
  chip.addEventListener("click", () => {
    input.value = chip.dataset.example;
    form.requestSubmit();
  });
});

btnReset.addEventListener("click", () => {
  stateResult.hidden = true;
  stateResult.classList.remove("is-safe", "is-danger");
  stateInput.hidden = false;
  input.value = "";
  input.focus();
});

async function runScan(url) {
  setLoading(true);
  const clientStart = performance.now();
  try {
    const res = await fetch("/scan", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ url }),
    });
    const data = await res.json();

    if (!res.ok) {
      fieldError.textContent = data.error || "Something went wrong. Please try again.";
      setLoading(false);
      return;
    }
    const clientMs = Math.round(performance.now() - clientStart);
    renderResult(data, clientMs);
  } catch (err) {
    fieldError.textContent = "Could not reach the CyberGuard server.";
  } finally {
    setLoading(false);
  }
}

function setLoading(isLoading) {
  scanBtn.disabled = isLoading;
  scanBtn.classList.toggle("loading", isLoading);
}

function renderResult(data, clientMs) {
  const isDanger = data.verdict === "Threat Detected";

  stateResult.classList.remove("is-safe", "is-danger");
  stateResult.classList.add(isDanger ? "is-danger" : "is-safe");
  resultIcon.innerHTML = isDanger ? ICON_WARN : ICON_CHECK;

  verdictText.textContent = isDanger ? "THREAT DETECTED" : "SAFE LINK";
  const label = isDanger ? "Hazard confidence" : "Benign confidence";
  confidenceText.textContent = `${label}: ${data.confidence}%`;

  detailUrl.textContent = data.url;
  detailProtocol.textContent = data.protocol;
  detailTime.textContent = `${data.response_ms} ms (server) · ${clientMs} ms (round-trip)`;

  if (data.whitelisted) {
    reasonLabel.textContent = "Reason";
    detailReason.textContent = data.reason;
    reasonRow.hidden = false;
    flaggedRow.hidden = true;
  } else if (isDanger) {
    flaggedRow.hidden = false;
    detailFlagged.innerHTML = data.flagged.map((f) => `<li>${escapeHtml(f)}</li>`).join("");
    reasonRow.hidden = true;
  } else {
    reasonLabel.textContent = "Reason";
    detailReason.textContent = "No suspicious structural patterns detected; not on the trusted whitelist.";
    reasonRow.hidden = false;
    flaggedRow.hidden = true;
  }

  stateInput.hidden = true;
  stateResult.hidden = false;
}

function escapeHtml(str) {
  const div = document.createElement("div");
  div.textContent = str;
  return div.innerHTML;
}
