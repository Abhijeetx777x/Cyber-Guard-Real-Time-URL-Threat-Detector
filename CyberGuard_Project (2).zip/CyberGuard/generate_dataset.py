"""
generate_dataset.py
--------------------
Builds a labelled dataset of legitimate ("good") and phishing-style ("bad")
URLs for training CyberGuard's Random Forest classifier.

Legitimate URLs are built from a large list of real, well-known domains
combined with realistic paths/query strings. Phishing-style URLs are
synthesised using patterns that are well documented in phishing research:
raw IP hosts, brand-name typosquatting, excessive hyphens/subdomains,
suspicious free TLDs, credential-harvesting keywords, and insecure
(HTTP) protocol usage.

Output: data/url_dataset.csv  with columns [url, label]  (label: 1=phishing, 0=legit)
"""
import csv
import random

random.seed(42)

# ---------------------------------------------------------------------
# Real, well-known legitimate domains (used to build benign examples)
# ---------------------------------------------------------------------
LEGIT_DOMAINS = [
    "google.com", "github.com", "wikipedia.org", "microsoft.com", "apple.com",
    "amazon.com", "nytimes.com", "bbc.com", "wikipedia.org", "reddit.com",
    "stackoverflow.com", "linkedin.com", "python.org", "mozilla.org",
    "cloudflare.com", "npmjs.com", "docs.python.org", "developer.mozilla.org",
    "wordpress.com", "medium.com", "dropbox.com", "spotify.com", "netflix.com",
    "adobe.com", "salesforce.com", "oracle.com", "ibm.com", "intel.com",
    "samsung.com", "nasa.gov", "who.int", "un.org", "harvard.edu", "mit.edu",
    "stanford.edu", "cam.ac.uk", "gov.uk", "irctc.co.in", "rbi.org.in",
    "uidai.gov.in", "nic.in", "flipkart.com", "paypal.com", "ebay.com",
    "twitter.com", "x.com", "instagram.com", "facebook.com", "youtube.com",
    "yahoo.com", "bing.com", "duckduckgo.com", "quora.com", "pinterest.com",
    "shopify.com", "wix.com", "godaddy.com", "digitalocean.com", "heroku.com",
    "atlassian.com", "slack.com", "zoom.us", "notion.so", "figma.com",
    "canva.com", "trello.com", "asana.com", "airbnb.com", "booking.com",
    "uber.com", "coursera.org", "udemy.com", "khanacademy.org", "edx.org",
    "researchgate.net", "sciencedirect.com", "springer.com", "ieee.org",
    "w3.org", "w3schools.com", "geeksforgeeks.org", "kaggle.com",
]

PATH_WORDS = [
    "products", "articles", "blog", "docs", "help", "support", "about",
    "contact", "search", "profile", "settings", "dashboard", "news",
    "video", "watch", "user", "post", "category", "index", "home",
    "login", "account", "cart", "checkout", "orders", "api", "v1", "v2",
]
QUERY_KEYS = ["id", "ref", "utm_source", "page", "q", "lang", "sort", "tab"]


def random_legit_url():
    domain = random.choice(LEGIT_DOMAINS)
    depth = random.randint(0, 3)
    path = "/".join(random.choice(PATH_WORDS) for _ in range(depth))
    url = f"https://www.{domain}/{path}" if path else f"https://www.{domain}/"
    if random.random() < 0.4:
        k = random.choice(QUERY_KEYS)
        v = random.choice([str(random.randint(1, 9999)), random.choice(PATH_WORDS), "en"])
        url += f"?{k}={v}"
    return url.rstrip("/") if url.count("/") > 3 else url


# Modern indie / startup-style legitimate domains: hyphenated names and
# non-.com TLDs are common here too, so the model must learn to rely on
# suspicious *keywords*, IP hosts, and known-bad TLDs — not just "has a
# hyphen" or "isn't .com" — to tell these apart from phishing links.
NAME_PARTS = ["cloud", "notes", "quick", "team", "sync", "daily", "sprout",
              "pixel", "atlas", "north", "byte", "harbor", "signal", "loop",
              "orbit", "trail", "maple", "canvas", "spark", "haven", "grove",
              "beacon", "drift", "kindred", "fable", "anchor", "vista"]
INDIE_TLDS = [".dev", ".io", ".co", ".app", ".so", ".ai", ".dev", ".net", ".org"]


def random_indie_legit_url():
    a, b = random.sample(NAME_PARTS, 2)
    sep = random.choice(["-", ""])
    tld = random.choice(INDIE_TLDS)
    depth = random.randint(0, 2)
    path = "/".join(random.choice(PATH_WORDS) for _ in range(depth))
    url = f"https://{a}{sep}{b}{tld}/{path}" if path else f"https://{a}{sep}{b}{tld}/"
    return url.rstrip("/")


# ---------------------------------------------------------------------
# Phishing-style synthetic generators
# ---------------------------------------------------------------------
BRANDS = ["paypal", "amazon", "netflix", "apple", "microsoft", "google",
          "instagram", "facebook", "hdfcbank", "icicibank", "sbi", "irctc",
          "flipkart", "whatsapp", "outlook", "chase", "wellsfargo", "dhl", "fedex"]
TYPO_SUFFIXES = ["-secure", "-verify", "-login", "-update", "-alert", "-confirm",
                  "-account", "-support", "1", "-id", "-service"]
SUSPICIOUS_TLDS = [".tk", ".ml", ".ga", ".cf", ".xyz", ".top", ".club", ".gq", ".info", ".click"]
KEYWORDS = ["login", "verify", "secure", "update", "account", "confirm",
            "suspended", "unlock", "billing", "signin", "reset-password", "webscr"]


def random_ip():
    return ".".join(str(random.randint(1, 254)) for _ in range(4))


def random_phish_url():
    kind = random.choice(["ip", "typosquat", "long_subdomain", "at_symbol", "keyword_stuff", "nohyphen_random"])
    protocol = "http" if random.random() < 0.75 else "https"  # phishing often skips TLS

    if kind == "ip":
        path = random.choice(KEYWORDS) + "/" + random.choice(KEYWORDS)
        return f"{protocol}://{random_ip()}/{path}.php"

    if kind == "typosquat":
        brand = random.choice(BRANDS)
        suffix = random.choice(TYPO_SUFFIXES)
        tld = random.choice(SUSPICIOUS_TLDS)
        sep = random.choice(["-", ""])
        return f"{protocol}://{brand}{sep}{suffix}.{random.choice(['com','net','org'])}{tld if random.random()<0.5 else ''}/{random.choice(KEYWORDS)}"

    if kind == "long_subdomain":
        brand = random.choice(BRANDS)
        junk = "-".join(random.choice(KEYWORDS) for _ in range(random.randint(2, 4)))
        tld = random.choice(SUSPICIOUS_TLDS)
        return f"{protocol}://{junk}-{brand}{tld}/{random.choice(KEYWORDS)}.html"

    if kind == "at_symbol":
        brand = random.choice(BRANDS)
        return f"{protocol}://{brand}.com@{random_ip()}/{random.choice(KEYWORDS)}"

    if kind == "nohyphen_random":
        # No hyphens at all: a random alphanumeric token + brand + suspicious
        # TLD. Ensures the model can't rely on "contains a hyphen" alone.
        token = "".join(random.choices("abcdefghijklmnopqrstuvwxyz0123456789", k=random.randint(5, 9)))
        brand = random.choice(BRANDS)
        tld = random.choice(SUSPICIOUS_TLDS)
        return f"{protocol}://{token}{brand}{tld}/{random.choice(KEYWORDS)}.php?id={random.randint(100,9999)}"

    # keyword_stuff
    brand = random.choice(BRANDS)
    stuffing = "-".join(random.sample(KEYWORDS, k=random.randint(2, 3)))
    tld = random.choice(SUSPICIOUS_TLDS)
    return f"{protocol}://{brand}-{stuffing}{tld}/index.php?id={random.randint(1000,99999)}"


def build_dataset(n_per_class=4000):
    rows = []
    seen = set()
    # 70% from well-known real domains, 30% modern indie/startup-style —
    # gives the legitimate class realistic diversity in TLD/hyphen usage.
    n_known = int(n_per_class * 0.55)
    n_indie = n_per_class - n_known
    known_count = 0
    while known_count < n_known:
        u = random_legit_url()
        if u not in seen:
            seen.add(u)
            rows.append((u, 0))
            known_count += 1
    indie_count = 0
    while indie_count < n_indie:
        u = random_indie_legit_url()
        if u not in seen:
            seen.add(u)
            rows.append((u, 0))
            indie_count += 1
    while sum(1 for r in rows if r[1] == 1) < n_per_class:
        u = random_phish_url()
        if u not in seen:
            seen.add(u)
            rows.append((u, 1))
    random.shuffle(rows)
    return rows


if __name__ == "__main__":
    rows = build_dataset(4000)
    with open("data/url_dataset.csv", "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["url", "label"])
        w.writerows(rows)
    print(f"Wrote {len(rows)} rows to data/url_dataset.csv "
          f"({sum(1 for r in rows if r[1]==0)} legit / {sum(1 for r in rows if r[1]==1)} phishing)")
