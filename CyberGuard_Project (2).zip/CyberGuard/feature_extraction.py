"""
feature_extraction.py
----------------------
Derives structural / lexical features from a raw URL string. No network
request is ever made and no page content is fetched — every feature is
computed purely from the URL text itself, which is what keeps CyberGuard's
scan both instant and safe to run on links that have not been vetted.
"""
import re
from urllib.parse import urlparse

IP_PATTERN = re.compile(r"^\d{1,3}(\.\d{1,3}){3}$")
SPECIAL_CHARS = (".", "-", "@")

FEATURE_NAMES = [
    "url_length",
    "domain_length",
    "special_chars",
    "has_ip_address",
    "is_https",
]


def get_domain(url: str) -> str:
    """Return the network location (domain[:port]) of a URL, tolerating
    input that is missing a scheme (e.g. 'example.com/path')."""
    if "://" not in url:
        url = f"http://{url}"
    return urlparse(url).netloc.split("@")[-1]  # ignore userinfo@ tricks for the domain itself


def extract_features(url: str) -> dict:
    """Derive structural features from a raw URL string."""
    url = url.strip()
    domain = get_domain(url)
    return {
        "url_length": len(url),
        "domain_length": len(domain),
        "special_chars": sum(url.count(c) for c in SPECIAL_CHARS),
        "has_ip_address": int(bool(IP_PATTERN.match(domain))),
        "is_https": int(url.lower().startswith("https://")),
    }


def feature_vector(url: str) -> list:
    """Same as extract_features but as an ordered list, matching FEATURE_NAMES —
    this is the exact vector shape the trained model expects."""
    f = extract_features(url)
    return [f[name] for name in FEATURE_NAMES]


def feature_row(url: str):
    """Feature vector as a single-row pandas DataFrame with proper column
    names, which is what the trained scikit-learn model expects at
    inference time (avoids the 'missing feature names' warning)."""
    import pandas as pd
    return pd.DataFrame([feature_vector(url)], columns=FEATURE_NAMES)


if __name__ == "__main__":
    samples = [
        "https://www.github.com/anthropics",
        "http://192.168.44.10/login/verify.php",
        "http://secure-login-signin-chase.tk/billing.html",
    ]
    for s in samples:
        print(s, "->", extract_features(s))
